# AI Mode Studio

AI Mode Studio is a polished Android workspace for preparing visual context and prompts before continuing in [Google AI Mode](https://www.google.com/ai).

## Product experience

- Aurora dark visual system with premium glass-like cards and a custom launcher icon.
- Branded, adjustable Partial Custom Tab for `google.com/ai`, with tablet side-sheet behavior.
- Up to five local images with preview, persistent access, share-sheet intake, and long-press removal.
- Prompt studio with one-tap clipboard handoff.
- Local collage engine with branded export, smart layouts, rounded tiles, and MediaStore support.
- Production-safe manifest defaults: no backups, no cleartext traffic, and no debug flag.

## Build

Open the project in Android Studio, use JDK 17, sync Gradle, and run the `app` configuration.

The application ID is `app.aimode.studio`. It intentionally differs from the early prototype so development builds can be installed beside it without a signing-certificate conflict.

## Core promise

Images are prepared locally. Google AI Mode opens through a browser-owned Custom Tab; the app does not imitate Google sign-in or intercept Google credentials.
